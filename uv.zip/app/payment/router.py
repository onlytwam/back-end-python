"""
app/payment/router.py
─────────────────────
PayG payment endpoints wired into FastAPI.

  GET  /api/Payment/Callback   – browser redirect from PayG (success/fail)
  POST /api/Payment/Callback   – some PayG flows POST the result
  GET  /api/Payment/Status/{order_id} – frontend polls for payment status
  GET  /api/Payment/Config     – admin: view current PayG settings (masked)
  PUT  /api/Payment/Config     – admin: update PayG settings in the DB

Callback flow:
  1. Parse params from GET query string OR POST body
  2. FIX: PayG UAT does NOT append params to the RedirectUrl — instead we embed
     ?oid={order_id}&rid={unique_request_id} in the RedirectUrl ourselves, then
     call the PayG Detail API to get the real payment status
  3. Update Orders.state + payment fields in DB
  4. Write audit row to OrderRefund log
  5. Send email/SMS notification via existing ekart.notifications pipeline
  6. Redirect browser to frontend order-confirm or payment-failed page
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import RedirectResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from database import get_db
from app.auth.dependencies import get_current_user, require_roles, Roles, CurrentUser
from app.orders.models import Orders, OrderTrackingStatus, OrderRefund
from app.shared.app_settings import get_setting, reload_settings
from . import payg_client

router = APIRouter(prefix="/api/Payment", tags=["Payment"])


# ── Helpers ────────────────────────────────────────────────────────────────

def _frontend_url() -> str:
    return get_setting("frontend_base_url", "http://localhost:5173")


def _record_payment_log(
    db: Session,
    order_id: int,
    order_key_id: str,
    unique_request_id: str,
    payload: dict,
) -> None:
    """Write an audit row to the OrderRefund table."""
    try:
        merch_key_id_str = get_setting("payg_merchant_key_id", "0")
        merch_key_id = int(merch_key_id_str) if merch_key_id_str.isdigit() else 0
        log = OrderRefund(
            orderId                  = order_id,
            orderKeyId               = order_key_id,
            merchanKeyId             = merch_key_id,
            uniqueRequestId          = unique_request_id,
            orderStatus              = payload.get("OrderStatus", ""),
            paymentStatus            = payload.get("PaymentStatus"),
            paymentTransactionId     = payload.get("PaymentTransactionId", ""),
            paymentResponseCode      = payload.get("PaymentResponseCode"),
            paymentReasonCode        = payload.get("PaymentReasonCode", ""),
            paymentTransactionRefNo  = payload.get("PaymentTransactionRefNo", ""),
            paymentMethod            = payload.get("PaymentMethod", ""),
            paymentAccount           = payload.get("PaymentAccount", ""),
            createdDate              = datetime.now(timezone.utc),
            modifiedDate             = datetime.now(timezone.utc),
            deletedInd               = False,
        )
        db.add(log)
    except Exception as exc:
        print(f"[Payment] OrderRefund log failed for order {order_id}: {exc}")


def _update_order_after_payment(
    db: Session,
    order: Orders,
    response_code: int,
    payload: dict,
) -> None:
    """Update order state + payment columns from PayG callback data."""
    new_state = payg_client.payment_code_to_order_state(response_code)
    order.state                   = new_state
    order.paymentMethod           = payload.get("PaymentMethod") or order.paymentMethod
    order.paymentAccount          = payload.get("PaymentAccount") or order.paymentAccount
    order.paymentTransactionId    = payload.get("PaymentTransactionId", "")
    order.paymentTransactionRefNo = payload.get("PaymentTransactionRefNo", "")
    order.orderKeyId              = payload.get("OrderKeyId") or order.orderKeyId
    order.modifiedDate            = datetime.now(timezone.utc)
    db.add(order)
    db.add(OrderTrackingStatus(
        orderId     = order.orderId,
        status      = new_state,
        createdDate = datetime.now(timezone.utc),
    ))


def _send_payment_notification(db: Session, order_id: int, success: bool) -> None:
    try:
        if success:
            from app.ekart.notifications import send_order_placed_notification
            send_order_placed_notification(db, order_id)
    except Exception as exc:
        print(f"[Payment] Notification error for order {order_id}: {exc}")


def _enrich_params_via_detail_api(
    oid: str,
    rid: str,
) -> dict:
    """
    FIX: PayG UAT does not append params to the RedirectUrl.
    We embed ?oid=<order_id>&rid=<unique_request_id> in the RedirectUrl ourselves,
    then call the PayG Detail API here to get the real payment status.

    Returns a params dict shaped like a normal PayG callback payload so the
    rest of the callback handler works unchanged.
    """
    detail: dict = {}
    try:
        detail = payg_client.get_payg_order_detail(unique_request_id=rid)
        print(f"[Payment] Detail API response for rid={rid}: "
              f"code={detail.get('PaymentResponseCode')} status={detail.get('OrderStatus')}")
    except Exception as exc:
        print(f"[Payment] Detail API lookup failed for rid={rid}: {exc}")
        return {}

    # Extract transaction details from nested list
    txn_list = detail.get("OrderPaymentTransactionDetail") or []
    txn       = txn_list[0] if txn_list else {}

    return {
        "UserDefined1":          oid,
        "OrderKeyId":            detail.get("OrderKeyId", ""),
        "UniqueRequestId":       detail.get("UniqueRequestId", rid),
        "PaymentResponseCode":   detail.get("PaymentResponseCode", -1),
        "PaymentStatus":         detail.get("PaymentStatus"),
        "OrderStatus":           detail.get("OrderStatus", ""),
        "PaymentMethod":         detail.get("PaymentMethod") or txn.get("PaymentMethod", ""),
        "PaymentAccount":        detail.get("PaymentAccount") or txn.get("PaymentAccount", ""),
        "PaymentTransactionId":  str(txn.get("TransactionId", "")),
        "PaymentTransactionRefNo": str(txn.get("TransactionId", "")),
        "PaymentReasonCode":     txn.get("ResponseText", ""),
        "MID":                   get_setting("payg_mid"),
        "OrderAmount":           str(detail.get("OrderAmount", "")),
        # No HashData — UAT mode skips hash verification anyway
    }


# ── Callback ───────────────────────────────────────────────────────────────

@router.get("/Callback",  include_in_schema=True)
@router.post("/Callback", include_in_schema=True)
async def payment_callback(
    request: Request,
    db: Session = Depends(get_db),
):
    """
    PayG redirects the user's browser here after payment (GET or POST).
    Processes the result and redirects to the React frontend.
    """
    # ── 1. Parse whatever params came in ─────────────────────────────────
    params: dict = {}
    if request.method == "GET":
        params = dict(request.query_params)
    else:
        ct = request.headers.get("content-type", "")
        if "application/json" in ct:
            try:
                params = await request.json()
            except Exception:
                params = {}
        else:
            try:
                form = await request.form()
                params = dict(form)
            except Exception:
                params = {}

    print(f"[Payment] Callback raw params: {json.dumps(params, default=str)}")

    # ── 2. FIX: If PayG sent no payment params (UAT behaviour), use our
    #           embedded oid/rid to call the Detail API instead ────────────
    oid = params.get("oid", "")   # our own param embedded in redirect URL
    rid = params.get("rid", "")   # our own param embedded in redirect URL

    payg_gave_us_params = bool(
        params.get("PaymentResponseCode") is not None
        or params.get("OrderKeyId")
        or params.get("UserDefined1")
    )

    if not payg_gave_us_params and (oid or rid):
        print(f"[Payment] PayG sent no params — calling Detail API (oid={oid}, rid={rid})")
        enriched = _enrich_params_via_detail_api(oid, rid)
        if enriched:
            params = enriched
            print(f"[Payment] Enriched params: {json.dumps(params, default=str)}")

    # ── 3. Find the order ─────────────────────────────────────────────────
    order_id_str = params.get("UserDefined1") or oid or ""
    order_key_id = params.get("OrderKeyId", "")
    unique_req_id = params.get("UniqueRequestId", "") or rid

    order: Optional[Orders] = None
    if order_id_str:
        try:
            order = db.query(Orders).filter(
                Orders.orderId    == int(order_id_str),
                Orders.deletedInd == False,
            ).first()
        except Exception:
            pass

    if order is None and order_key_id:
        order = db.query(Orders).filter(
            Orders.orderKeyId  == order_key_id,
            Orders.deletedInd  == False,
        ).first()

    # Last resort: look up by UniqueRequestId stored in paymentTransactionRefNo
    if order is None and unique_req_id:
        order = db.query(Orders).filter(
            Orders.paymentTransactionRefNo == unique_req_id,
            Orders.deletedInd              == False,
        ).first()

    if order is None:
        print(f"[Payment] Callback: order not found — oid={oid}, rid={rid}, params={params}")
        return RedirectResponse(
            url         = f"{_frontend_url()}/user-products/payment-callback?status=error&message=Order+not+found",
            status_code = 302,
        )

    order_id = order.orderId

    # ── 4. Hash verification (skipped in UAT mode) ────────────────────────
    is_uat  = get_setting("payg_mode", "uat").lower() == "uat"
    hash_ok = payg_client.verify_callback_hash(params)
    if not is_uat and not hash_ok:
        print(f"[Payment] Callback: hash mismatch for order {order_id}")
        return RedirectResponse(
            url         = f"{_frontend_url()}/user-products/payment-callback?status=error&orderId={order_id}&message=Invalid+signature",
            status_code = 302,
        )

    # ── 5. Process response code ──────────────────────────────────────────
    try:
        response_code = int(params.get("PaymentResponseCode", -1))
    except (ValueError, TypeError):
        response_code = -1

    success = (response_code == 1)
    print(f"[Payment] Order {order_id} → PaymentResponseCode={response_code}, success={success}")

    try:
        _update_order_after_payment(db, order, response_code, params)
        _record_payment_log(db, order_id, order_key_id, unique_req_id, params)
        db.commit()
    except Exception as exc:
        db.rollback()
        print(f"[Payment] DB update failed for order {order_id}: {exc}")

    _send_payment_notification(db, order_id, success)

    # ── 6. Redirect user ──────────────────────────────────────────────────
    if success:
        redirect_url = f"{_frontend_url()}/user-products/order-confirm/{order_id}?payment=success"
    else:
        reason = params.get("PaymentReasonCode", "declined")
        redirect_url = (
            f"{_frontend_url()}/user-products/payment-callback"
            f"?status=failed&orderId={order_id}&code={response_code}&reason={reason}"
        )

    return RedirectResponse(url=redirect_url, status_code=302)


# ── Status poll ────────────────────────────────────────────────────────────

@router.get("/Status/{order_id}")
def get_payment_status(
    order_id: int,
    db: Session = Depends(get_db),
    current_user: CurrentUser = Depends(get_current_user),
):
    """
    Frontend can poll this to get the latest payment status.
    Also calls PayG detail API for a live update when an orderKeyId exists.
    """
    order = db.query(Orders).filter(
        Orders.orderId    == order_id,
        Orders.deletedInd == False,
    ).first()
    if not order:
        raise HTTPException(404, "Order not found")

    if current_user.role_id not in Roles.STAFF and order.userProfileId != current_user.user_id:
        raise HTTPException(403, "Not authorised")

    local_state = order.state or "Pending"
    payg_detail: dict = {}

    if order.orderKeyId or order.paymentTransactionRefNo:
        try:
            payg_detail = payg_client.get_payg_order_detail(
                order_key_id      = order.orderKeyId,
                unique_request_id = order.paymentTransactionRefNo,
            )
            live_code = payg_detail.get("PaymentResponseCode")
            if live_code is not None:
                live_state = payg_client.payment_code_to_order_state(int(live_code))
                if order.state != live_state:
                    order.state        = live_state
                    order.modifiedDate = datetime.now(timezone.utc)
                    db.add(order)
                    db.commit()
                    local_state = live_state
        except Exception as exc:
            print(f"[Payment] Live status check failed: {exc}")

    return {
        "orderId":              order_id,
        "orderNumber":          order.orderNumber,
        "state":                local_state,
        "paymentMethod":        order.paymentMethod,
        "paymentTransactionId": order.paymentTransactionId,
        "paymentResponseCode":  payg_detail.get("PaymentResponseCode"),
        "paygStatus":           payg_detail.get("OrderStatus"),
    }


# ── Admin: view / update PayG config ──────────────────────────────────────

class PaygConfigResponse(BaseModel):
    payg_mode:            str
    payg_mid:             str
    payg_auth_key:        str   # masked
    payg_auth_token:      str   # masked
    payg_secure_hash:     str   # masked
    payg_merchant_key_id: str
    payg_redirect_url:    str
    frontend_base_url:    str


class PaygConfigUpdate(BaseModel):
    payg_mode:            Optional[str] = None
    payg_mid:             Optional[str] = None
    payg_auth_key:        Optional[str] = None
    payg_auth_token:      Optional[str] = None
    payg_secure_hash:     Optional[str] = None
    payg_merchant_key_id: Optional[str] = None
    payg_redirect_url:    Optional[str] = None
    frontend_base_url:    Optional[str] = None


def _mask(v: str) -> str:
    if not v or len(v) <= 8:
        return "****"
    return v[:4] + "****" + v[-4:]


@router.get(
    "/Config",
    response_model = PaygConfigResponse,
    dependencies   = [Depends(require_roles(Roles.SUPER_ADMIN))],
)
def get_payg_config():
    """Admin: view current PayG settings (secrets are masked)."""
    return PaygConfigResponse(
        payg_mode            = get_setting("payg_mode", "uat"),
        payg_mid             = get_setting("payg_mid", ""),
        payg_auth_key        = _mask(get_setting("payg_auth_key", "")),
        payg_auth_token      = _mask(get_setting("payg_auth_token", "")),
        payg_secure_hash     = _mask(get_setting("payg_secure_hash", "")),
        payg_merchant_key_id = get_setting("payg_merchant_key_id", ""),
        payg_redirect_url    = get_setting("payg_redirect_url", ""),
        frontend_base_url    = get_setting("frontend_base_url", "http://localhost:5173"),
    )


@router.put(
    "/Config",
    dependencies = [Depends(require_roles(Roles.SUPER_ADMIN))],
)
def update_payg_config(
    data: PaygConfigUpdate,
    db: Session = Depends(get_db),
):
    """Admin: update one or more PayG settings in the DB."""
    from app.common.models import AppSettings

    updates = {k: v for k, v in data.model_dump().items() if v is not None}
    now = datetime.now(timezone.utc)

    for key, value in updates.items():
        row = (
            db.query(AppSettings)
            .filter(AppSettings.key == key, AppSettings.deletedInd == False)
            .first()
        )
        if row:
            row.value        = value
            row.modifiedDate = now
        else:
            db.add(AppSettings(
                key          = key,
                value        = value,
                description  = f"PayG setting: {key}",
                isActive     = True,
                createdDate  = now,
                modifiedDate = now,
                deletedInd   = False,
            ))

    db.commit()
    reload_settings(db)
    return {"success": True, "updated": list(updates.keys())}